import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		//ex_6_1();
		//ex_6_2();
		//ex_6_3();
		//ex_6_18();
		//ex_6_31();
		//ex_6_36();
	}
	
	
	
	
	
	
	
	
	// ################################################
	//				EXERCISE 6.1
	// ################################################
	static void ex_6_1() {

	}
	
	/* IMPLEMENT ADDITIONAL FUNCTIONS HERE */
	
	
	
	
	
	
	
	
	
	
	
	
	
	// ################################################
	//				EXERCISE 6.2
	// ################################################
	static void ex_6_2() {

	}

		
	/* IMPLEMENT ADDITIONAL FUNCTIONS HERE */
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// ################################################
	//				EXERCISE 6.3
	// ################################################
	static void ex_6_3() {

	}

	
	/* IMPLEMENT ADDITIONAL FUNCTIONS HERE */
	
	
	
	
	
	
	
	
	
	
	
	
	// ################################################
	//				EXERCISE 6.18
	// ################################################
	static void ex_6_18() {

	}
	
	public static boolean isValidPassword(String pw) {

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// ################################################
	//				EXERCISE 6.31
	// ################################################
	static void ex_6_31() {
		System.out.println(isValid(5105105105105100L));
	}
	
	public static boolean prefixMatched(long number, int d) {
		return getPrefix(number, getSize(d)) == d;
	}

	/* IMPLEMENT ADDITIONAL FUNCTIONS HERE */
	
	
	
	
	
	
	
	
	
	
	// ################################################
	//				EXERCISE 6.36
	// ################################################
	static void ex_6_36() {

	}
	
	/* IMPLEMENT ADDITIONAL FUNCTIONS HERE */

}
