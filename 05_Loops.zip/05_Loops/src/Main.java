import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		//ex_5_1();
		//ex_5_7();
		//ex_5_10();
		//ex_5_12();
		//ex_5_13();
		//ex_5_30();
		//ex_5_41();
		//ex_5_43();
	}
	
	static void ex_5_1() {

	}
	
	static void ex_5_7() {

	}

	static void ex_5_10() {

	}
	
	static void ex_5_12() {

	}
	
	static void ex_5_13() {

	}

	static void ex_5_30() {

	}
	
	static void ex_5_41() {

	}

	static void ex_5_43() {

	}
}
